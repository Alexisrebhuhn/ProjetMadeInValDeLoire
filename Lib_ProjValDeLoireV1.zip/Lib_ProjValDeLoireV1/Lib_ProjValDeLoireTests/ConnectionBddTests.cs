﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lib_ProjValDeLoire;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib_ProjValDeLoire.Tests
{
    [TestClass()]
    public class ConnectionBddTests
    {
        [TestMethod()]
        public void ConnectionABaseTest()
        {

        }

        [TestMethod()]
        public void deconnexionTest()
        {

        }
    }
}